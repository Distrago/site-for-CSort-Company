#from logging import exception
from flask import Flask, jsonify, render_template, request, send_from_directory

import io
from msilib.schema import Component
import os
import json
import math

import api_google
import requests
from datetime import datetime
from datetime import timedelta

#Google API service
service = api_google.service_sheets

MYDIR = os.path.dirname(__file__)
app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 300
app.config['JSON_AS_ASCII'] = False
app.debug = True

@app.route('/smartsortb.ru')
def smartsortb():
    return send_from_directory(os.path.join(app.root_path, 'static'),'smartsortb.ru')

def find_by_key(List, key, value):
    for index, dict_ in enumerate(List):
        if key in dict_ and dict_[key] == value:
            return (dict_['idReq'])

