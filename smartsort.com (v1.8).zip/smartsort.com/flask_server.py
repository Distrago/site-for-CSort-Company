
from flask import Flask, jsonify, render_template, request, send_from_directory, redirect, url_for, session

import io
import os
import json
import math
import random 
import string
import api_google
import requests
from datetime import datetime
from datetime import timedelta
import time

#Google API service
service = api_google.service_sheets

MYDIR = os.path.dirname(__file__)
app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 300
app.config['JSON_AS_ASCII'] = False
app.debug = True

@app.route('/favicon.ico')
def fav():
    return send_from_directory(os.path.join(app.root_path, 'static'),'favicon.ico')


@app.route('/smartsort')
def web_template_specific():
    langBr = request.accept_languages[0][0].split('-')[1]
    lang = request.args.get('lang')    
    if lang != None:
        return render_template('smartsort'+ lang.upper() +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    else:
        return render_template('smartsort'+ langBr +'.html', last_updated=dir_last_updated(MYDIR+'/static'))

@app.route('/smartsort/accuracy')
def web_template_specificA():
    langBr = request.accept_languages[0][0].split('-')[1]
    lang = request.args.get('lang')    
    if lang != None:
        return render_template('accuracy'+ lang.upper() +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    else:
        return render_template('accuracy'+ langBr +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    
@app.route('/smartsort/about')
def web_template_specificC():
    langBr = request.accept_languages[0][0].split('-')[1]
    lang = request.args.get('lang')    
    if lang != None:
        return render_template('about'+ lang.upper() +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    else:
        return render_template('about'+ langBr +'.html', last_updated=dir_last_updated(MYDIR+'/static'))

@app.route('/smartsort/product')
def web_template_specificP():
    langBr = request.accept_languages[0][0].split('-')[1]
    lang = request.args.get('lang')    
    if lang != None:
        return render_template('product'+ lang.upper() +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    else:
        return render_template('product'+ langBr +'.html', last_updated=dir_last_updated(MYDIR+'/static'))

@app.route('/smartsort/features')
def web_template_specificF():
    langBr = request.accept_languages[0][0].split('-')[1]
    lang = request.args.get('lang')    
    if lang != None:
        return render_template('features'+ lang.upper() +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    else:
        return render_template('features'+ langBr +'.html', last_updated=dir_last_updated(MYDIR+'/static'))

@app.route('/smartsort/contact')
def web_template_specificK():
    langBr = request.accept_languages[0][0].split('-')[1]
    lang = request.args.get('lang')    
    if lang != None:
        return render_template('contacts'+ lang.upper() +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    else:
        return render_template('contacts'+ langBr +'.html', last_updated=dir_last_updated(MYDIR+'/static'))

@app.route('/smartsort/models')
def web_template_specificM():
    langBr = request.accept_languages[0][0].split('-')[1]
    lang = request.args.get('lang')    
    if lang != None:
        return render_template('model'+ lang.upper() +'.html', last_updated=dir_last_updated(MYDIR+'/static'))
    else:
        return render_template('model'+ langBr +'.html', last_updated=dir_last_updated(MYDIR+'/static'))



def dir_last_updated(folder):
    return str(max(os.path.getmtime(os.path.join(root_path, f))
        for root_path, dirs, files in os.walk(folder)
        for f in files))
 
def find_by_key(List, key, value):
    for index, dict_ in enumerate(List):
        if key in dict_ and dict_[key] == value:
            return (dict_['idReq'])


if __name__ == "__main__":
       
    app.run()