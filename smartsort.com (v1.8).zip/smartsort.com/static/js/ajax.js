function smartsort(){
    var _date = {
        'lang': 'en'
    } 
    $.ajax({
        url: '/changeLang', 
        type: 'post',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(_date),
        success: function(data){
            
        },
        error: function (error) {
            
        }
    })
}
