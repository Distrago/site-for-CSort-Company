// var GlobalLang = document.documentElement.lang;
var GlobalLang = 'ru';
// var GlobalLang;
var active = false;
var counter = 0;
var direction = 0;
var directionYT = 0;
productCounter = 0;
var YTCounter = 0;
val = 0;
var valYT = 0;
var position = 0;
var productMass = {
	"0": ['arIn.jpg', 'arOut.jpg'],
	"1": ['granIn.jpg','granOut.jpg'],
	"2": ['BuckwheatIn.jpg','BuckwheatOut.jpg'],
	"3": ['CorianderIN.jpg','CorianderOUT.jpg'],
	"4": ['cornIN.jpg','cornOUT.jpg'],
	"5": ['OatsIN.jpg','OatsOUT.jpg'],
	"6": ['Oats2IN.jpg','Oats2OUT.jpg'],
	"7": ['Wheat-from-barleyIN.jpg','Wheat-from-barleyOUT.jpg'],
	"8": ['WheatIN.jpg','WheatOUT.jpg'],
	"9": ['RapeIN.jpg','RapeOUT.jpg'],
	"10": ['RyeIN.jpg','RyeOUT.jpg'],
	"11": ['BeansIN.jpg','BeansOUT.jpg'],
	"12": ['PistachioIN.jpg','PistachioOUT.jpg'],
	"13": ['LentilsIN.jpg','LentilsOUT.jpg']
}
var hType = 0;
var srcYT = {
	"0":"https://www.youtube.com/embed/guy4tVAinXw?si=GNODEngA-RN5FdB8",
	"1":"https://www.youtube.com/embed/eJ3roS6U178?si=5RulXatOloy_QPnG",
	"2":"https://www.youtube.com/embed/Sw_qPHXJt2E?si=54WUUMQ-_tcGsYXU",
	"3":"https://www.youtube.com/embed/od73Mp89hzo?si=a66mwzJevB_kltU_",
	"4":"https://www.youtube.com/embed/KWyymTwbEKE?si=HidQ5EG2NMPIWJbu",
	"5":"https://www.youtube.com/embed/TwYK4047m5s?si=oZZYMgJ7l-XtypAB",
	"6":"https://www.youtube.com/embed/1a9bKI5pmbg?si=jSFcP5xkVOkuJ6nF",
	"7":"https://www.youtube.com/embed/OyJJ2ChQrYs?si=E9_gQ-9WjjZxDD3T",
	"8":"https://www.youtube.com/embed/cmEvD1WMpQ8?si=T4l5W59_DmaE-x2Q",
	"9":"https://www.youtube.com/embed/Q9v-M7usrVQ?si=95_H0-LHhHrPeNWU"
}
function onload(){
	try{
		sortSliderRun(1);
	}
	catch{
		
	}
	initslider();
	
}
async function checkGlobalLang(){
	var params = new URLSearchParams(window.location.search);
	GlobalLang = params.get('lang') != null ? params.get('lang') : 'ru';
	LanguageSelector.value = GlobalLang;
}
// СЛАЙДЕР ПРОДУКТОВ
function sortSliderRun(id){
	// var scrollerMiddle = document.querySelector('.scroller-middle');
	var scrollerMiddle = document.getElementById('scroller-middle_' + id);
	var wrapper = document.getElementById('wrapper_' + id);
	scrollerMiddle.addEventListener('mousedown',function(){
		active = "middle";
		scrollerMiddle.classList.add('scrolling');
	});
	document.body.addEventListener('mouseup',function(){
		active = false;
		scrollerMiddle.classList.remove('scrolling');
	});
	document.body.addEventListener('mouseleave',function(){
		active = false;
		scrollerMiddle.classList.remove('scrolling');
	});		
	document.body.addEventListener('mousemove',function(e){
		if (!active) return;
		var x = e.pageX;
		// x -= document.querySelector('.wrapper').getBoundingClientRect().left;
		x -= wrapper.getBoundingClientRect().left;
		scrollIt(x,id);
	});
	active = "middle";
	scrollIt(460,id);
	active = false;
	scrollerMiddle.addEventListener('touchstart',function(){
		active = "middle";
		scrollerMiddle.classList.add('scrolling');
	});
	document.body.addEventListener('touchend',function(){
		active = false;
		scrollerMiddle.classList.remove('scrolling');
	});
	document.body.addEventListener('touchcancel',function(){
		active = false;
		scrollerMiddle.classList.remove('scrolling');
	});

	// document.querySelector('.wrapper').addEventListener('touchmove',function(e){
	wrapper.addEventListener('touchmove',function(e){
		if (!active) return;
		e.preventDefault();
		var x = e.touches[0].pageX;
		// x -= document.querySelector('.wrapper').getBoundingClientRect().left;
		x -= wrapper.getBoundingClientRect().left;
		scrollIt(x,id);
	});
}

function scrollIt(x, id){
//   var transform = Math.max(0,(Math.min(x,document.querySelector('.wrapper').offsetWidth)));
  var transform = Math.max(0,(Math.min(x,document.getElementById('wrapper_' + id).offsetWidth)));
//   var scrollerMiddle = document.querySelector('.scroller-middle');
  var scrollerMiddle = document.getElementById('scroller-middle_' + id);
  if (active==="middle"){
    // document.querySelector('.middle').style.width = transform+"px";
    document.getElementById('middle_' + id).style.width = transform+"px";
    scrollerMiddle.style.left = transform-25+"px";    
  }
}

// СКРОЛЛЕР ПРОДУКТОВ
function RBProd(){
	direction = 'Right';
	productCounter = productCounter+1;
	if(productCounter > 13){
		productCounter = 0;
	}
	val = 1;
	
	firstStep();
	setProduct();
	console.log(productCounter);
	setTimeout(nextStep, 800);
}
function firstStep(){
	var scroller = document.getElementById('scroller-middle_1');
	position = scroller.style.left;
	var newWrap = wrapper_0.cloneNode(true);
	var nextslide = document.createElement('div');
	
	nextslide.append(newWrap);
	newWrap.style.display = 'flex';
	newWrap.children[0].children[0].style="background-image: url(/static/img/comp/"+productMass[productCounter][1]+");"
	newWrap.children[1].children[0].style="background-image: url(/static/img/comp/"+productMass[productCounter][0]+");"
	switch(direction){
		case"Left":
			nextslide.className = 'PRODUCT_2';			
			linePR.prepend(nextslide);
			break;
		case"Right":
			nextslide.className = 'PRODUCT_0';
			linePR.append(nextslide);
			break;
	}	
	
}
function nextStep(){
	switch(direction){
		case"Left":
			linePR.children[1].remove();
			linePR.children[0].id = 'PR_1';
			linePR.children[0].children[0].id = 'wrapper_' + (1);
			linePR.children[0].children[0].children[1].id = 'middle_' + (1);
			linePR.children[0].children[0].children[2].id = 'scroller-middle_' + (1);
			break;
		case"Right":
			linePR.children[0].remove();
			linePR.children[0].id = 'PR_1';
			linePR.children[0].children[0].id = 'wrapper_' + (1);
			linePR.children[0].children[0].children[1].id = 'middle_' + (1);
			linePR.children[0].children[0].children[2].id = 'scroller-middle_' + (1);
			break;
	}
	sortSliderRun(1);
	wrapper_1.children[2].style.left = position;
	wrapper_1.children[1].style.width = (Number(position.split('p')[0])+ 25) + 'px';
}
function LBProd(){	
	direction = 'Left';
	productCounter = productCounter-1;
	if(productCounter < 0){
		productCounter = 13;
	}
	val = 2;
	firstStep();
	setProduct();
	console.log(productCounter);
	setTimeout(nextStep, 800);
	
}
function setProduct(){	
	var PR_1 = document.getElementById('PR_1');
	PR_1.className = 'PRODUCT_' + val;
	
}



// СКРОЛЛЕР ТЕХНИКИ
var imgBlock = ['SmartSort-C-1.png','SmartSort-C-2.png','SmartSort-C-3.png','SmartSort-C-4.png','SmartSort-C-5.png','SmartSort-C-6.png'];
var activeImg = 0;
var slider 
var slides  
var slideCount 
let slideIndex = 0;
var flag = true;
// Измененная  функция
function initslider(){
	let Parent = document.getElementsByClassName('swiper-wrapper')[0]
	let Children = Parent.children[0]
	for (var i = 0; i < imgBlock.length; i++) { //прогоняем все элементы скрол блока
		img = document.createElement('img')
		let Clone = Children.cloneNode(true)

		Clone.style.display = 'flex'
		img.id = 'newSlide_' + i
		img.alt = '';
		img.src = '/static/img/apparat/' + imgBlock[i];
		img.classList.add('imgParametr')
		Clone.appendChild(img)
		Parent.appendChild(Clone)

	}
	document.getElementById('StartSlide').remove()

	slider = document.querySelector('.mySwiper');
	slides = Array.from(slider.querySelectorAll('img'));
	slideCount = slides.length;

	var swiper = new Swiper(".mySwiper", {
		slidesPerView: 1,
		loop: true,
		navigation: {
		  nextEl: ".swiper-button-next",
		  prevEl: ".swiper-button-prev",
		},
		on: {
			slideNextTransitionEnd: function (swiper) {
				showNextSlide()
			},
			slidePrevTransitionEnd: function (swiper) {
				showPreviousSlide()
			}
		  }
	  });
	
}
// новая функция
function showPreviousSlide() {
	slideIndex = (slideIndex - 1 + slideCount) % slideCount;
	SlideText(slideIndex)
}
// новая функция
function showNextSlide() {
	slideIndex = (slideIndex + 1) % slideCount;
	SlideText(slideIndex)
}
// новая функция
function SlideText(slideIndex){
	for (var n = 1; n <= 5; n++) { //прогоняем все элементы скрол блока
		var slP = document.getElementById('slP_' + n);
		for (var i = 0; i < slP.children.length; i++) { //прогоняем все элементы скрол блока
			i == slideIndex ? slP.children[i].style.display = 'flex':slP.children[i].style.display = 'none'
		}
	}
}



// Функция для обновления отображения слайдера
function updateSlider() {
slides.forEach((slide, index) => {
	if (index === slideIndex) {
	slide.style.display = 'block';
	} else {
	slide.style.display = 'none';
	}
});
}

function animate({duration, draw, removeElement}){
	var start = performance.now();

	requestAnimationFrame(function animate(time){
		var step = (time - start) / duration;
		if(step > 1) step = 1;
		draw(step);
		if(step < 1){
			requestAnimationFrame(animate);
		}
		else{
			if(removeElement != null) removeElement.remove();

			flag = true;
		}
	});
}

function setText(val){
	
	var slP_1 = document.getElementById('slP_1');
	var slP_2 = document.getElementById('slP_2');
	var slP_3 = document.getElementById('slP_3');
	var slP_4 = document.getElementById('slP_4');
	var slP_5 = document.getElementById('slP_5');

	slP_1.children[0].className = 'slT_' + val;
	slP_2.children[0].className = 'slT_' + val;
	slP_3.children[0].className = 'slT_' + val;
	slP_4.children[0].className = 'slT_' + val;
	slP_5.children[0].className = 'slT_' + val;
	
}

function setIMGsize(){
	var SLplace = document.getElementById('SLSpace');
	SLplace.children[0].style = 'width:200px; margin: 0 20px 0 110px';
	SLplace.children[2].style = 'width:200px;';
}

function openMain(){
	window.open("/smartsort?lang=" + GlobalLang,"_self");
}

function openModel(){
	window.open("/smartsort/models?lang=" + GlobalLang,"_self");
}
function openContacts(){
	window.open("/smartsort/contact?lang=" + GlobalLang,"_self");
}
function openAbout(){
	window.open("/smartsort/about?lang=" + GlobalLang,"_self");
}
function openProduct(){
	window.open("/smartsort/product?lang=" + GlobalLang,"_self");
}
function openAccuracy(){
	window.open("/smartsort/accuracy?lang=" + GlobalLang,"_self");
}
function  openFeatures(){
	window.open("/smartsort/features?lang=" + GlobalLang,"_self");
}


// СКРОЛЛЕР YT
function RBYT(){
	directionYT = 'Right';
	YTCounter = YTCounter+1;
	if(YTCounter > 9){
		YTCounter = 0;
	}
	valYT = 1;
	firstStepYT();
	setVideo();
	console.log(YTCounter);
	setTimeout(nextStepYT, 800);

}
function firstStepYT(){
	newFrame = YTFrame_0.cloneNode(true);	
	var nextslide = document.createElement('div');
	
	nextslide.append(newFrame);
	newFrame.style.display = 'flex';
	newFrame.src = srcYT[YTCounter];
	switch(directionYT){
		case"Left":
			nextslide.className = 'YT_2';
			lineYT.prepend(nextslide);
			break;
		case"Right":
			nextslide.className = 'YT_0';
			lineYT.append(nextslide);
			break;
	}	
	
}
function nextStepYT(){
	switch(directionYT){
		case"Left":
			lineYT.children[1].remove();
			lineYT.children[0].id = 'YT_1';
			lineYT.children[0].children[0].id = 'YTFrame_' + (1);
			break;
		case"Right":
			lineYT.children[0].remove();
			lineYT.children[0].id = 'YT_1';
			lineYT.children[0].children[0].id = 'YTFrame_' + (1);
			break;
	}
}
function LBYT(){
	directionYT = 'Left';
	YTCounter = YTCounter-1;
	if(YTCounter < 0){
		YTCounter = 9;
	}
	valYT = 2;
	firstStepYT();
	setVideo();
	console.log(YTCounter);
	setTimeout(nextStepYT, 800);
	
}
function setVideo(){
	var YT_1 = document.getElementById('YT_1');
	YT_1.className = 'YT_' + valYT;
	
}

function openLink(ID){
	var main = ID.parentNode.parentNode;
	var infoBlock = main.children[1];
	var plus = ID.parentNode.children[0];
	var after = featuresMainBlock.getElementsByClassName('after');
	var des2 = featuresMainBlock.getElementsByClassName('description2');
	var checkH =  getComputedStyle(infoBlock).height;
	
	for(var i = 0; i < after.length; i++){
		after[i].parentNode.children[0].style.display = 'block';
		after[i].classList.replace('after', 'link');
	}
	for(var i = 0; i < des2.length; i++){
		des2[i].classList.replace('description2', 'description');
	}
	if(checkH == '0px'){
		plus.style.display = 'none';
		infoBlock.classList.replace('description', 'description2');
		ID.classList.replace('link', 'after');
	}
	// .classList.replace(1arguments, 2arg)
}

function toggleMobileMenu(menu){
	var hamburger = menu.parentNode;
	hamburger.children[1].style.display = hamburger.children[1].style.display == 'flex' ? 'none' : 'flex';
	hType = hType == 1 ? 0 : 1;
	if(hType == 1){
		header.style.height = "600px";
	}
	else header.style.height = "100px";
}
function toggleMobileMenu2(menu){
	var hamburger = menu.parentNode;
	hamburger.children[1].style.display = hamburger.children[1].style.display == 'flex' ? 'none' : 'flex';
	hType = hType == 1 ? 0 : 1;
	if(hType == 1){
		header.style.height = "600px";
		modelMain.parentNode.style = "margin-top:450px";
	}
	else{
		header.style.height = "100px";
		modelMain.parentNode.style = "margin-top:0px";
	} 
}


function globalLangChange(){
	GlobalLang = LanguageSelector.value;
	var main_link = window.location.href.split("/")[3].split("?")[0];	
	if(window.location.href.split("/").length > 4){
		var current_link = window.location.href.split("/")[4].split("?")[0];
		window.open("/"+main_link+"/"+current_link+"?lang=" + GlobalLang,"_self")
	}
	else{
		window.open("/"+main_link+"?lang=" + GlobalLang,"_self")
	} 
	// checkGlobalLang();
}